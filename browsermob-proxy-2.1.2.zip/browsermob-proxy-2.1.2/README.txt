Please see README.md (in Markdown format) or view it at:

https://github.com/lightbody/browsermob-proxy